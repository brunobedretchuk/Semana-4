class Conta {
    constructor (numConta , saldo , cliente){
        this.numConta = numConta;
        this.saldo = saldo;
        this.cliente = cliente;
        }
}
