class Endereço {
    constructor (logradouro , num , cidade , estado , pais , cep){
        this.logradouro = logradouro;
        this.num = num;
        this.cidade = cidade;
        this.estado = estado;
        this.pais = pais;
        this.cep = cep;
    }
}
