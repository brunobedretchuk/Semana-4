class Cliente {
    constructor (nome , cpf , endereco , cel){
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.cel = cel;
    }
}
